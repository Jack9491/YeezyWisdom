package com.example.YeezyWisdom.service;

import com.example.YeezyWisdom.model.Quote;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.time.Duration;

@Service
public class QuoteService {

    private final WebClient webClient;

    public QuoteService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://api.kanye.rest").build();
    }

    public Flux<Quote> streamQuotes() {
        return Flux.interval(Duration.ofSeconds(25)) // Fetch every 5 seconds
                .flatMap(i -> fetchQuote());
    }

    private Flux<Quote> fetchQuote() {
        return webClient.get()
                .retrieve()
                .bodyToMono(Quote.class)
                .flux()
                .map(quote -> {
                    quote.setTimestamp(System.currentTimeMillis()); // Add timestamp
                    return quote;
                });
    }
}
