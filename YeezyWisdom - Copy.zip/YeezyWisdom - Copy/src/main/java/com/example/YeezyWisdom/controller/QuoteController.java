package com.example.YeezyWisdom.controller;

import com.example.YeezyWisdom.model.Quote;
import com.example.YeezyWisdom.service.QuoteService;
import com.example.YeezyWisdom.repository.QuoteRepository;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/quotes")
public class QuoteController {

    private final QuoteService quoteService;
    private final QuoteRepository quoteRepository;

    public QuoteController(QuoteService quoteService, QuoteRepository quoteRepository) {
        this.quoteService = quoteService;
        this.quoteRepository = quoteRepository;
    }

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Quote> streamQuotes() {
        return quoteService.streamQuotes()
                .doOnNext(quote -> quoteRepository.save(quote).subscribe());
    }
}
