package com.example.YeezyWisdom.controller;

import com.example.YeezyWisdom.model.Quote;
import com.example.YeezyWisdom.repository.QuoteRepository;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/quotes")
public class QuoteCrudController {

    private final QuoteRepository quoteRepository;

    public QuoteCrudController(QuoteRepository quoteRepository) {
        this.quoteRepository = quoteRepository;
    }

    @GetMapping("/{id}")
    public Mono<Quote> getQuoteById(@PathVariable String id) {
        return quoteRepository.findById(id);
    }

    @GetMapping
    public Flux<Quote> getAllQuotes() {
        return quoteRepository.findAll();
    }

    @PostMapping
    public Mono<Quote> createQuote(@RequestBody Quote quote) {
        return quoteRepository.save(quote);
    }

    @PutMapping("/{id}")
    public Mono<Quote> updateQuote(@PathVariable String id, @RequestBody Quote updatedQuote) {
        return quoteRepository.findById(id)
                .flatMap(existingQuote -> {
                    existingQuote.setQuote(updatedQuote.getQuote());
                    return quoteRepository.save(existingQuote);
                });
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deleteQuote(@PathVariable String id) {
        return quoteRepository.deleteById(id);
    }
}
