package com.example.YeezyWisdom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YeezyWisdomApplicationTests {

	@Test
	void contextLoads() {
	}

}
